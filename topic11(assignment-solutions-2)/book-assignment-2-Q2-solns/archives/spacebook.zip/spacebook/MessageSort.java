import java.util.ArrayList;

public class MessageSort
{
    //Task 9
    public static void sortMessages(Message[] m)
    {
        for(int i = 1; i < m.length; i += 1)
        {
            for(int j = i; j < m.length; j += 1) 
            {
                if(m[i].messageText.compareTo(m[j].messageText) > 0)
                {
                    swap(m, i, j);
                }
            }
        }  
    }

    private static void swap(Message[] arMsg, int to, int from)
    {
        Message temp = arMsg[to];
        arMsg[to] = arMsg[from];
        arMsg[from] = temp;
    }

    //Task 10
    public static void sortMessages(ArrayList<Message> m)
    {
        for (int i = 0; i < m.size(); i += 1)
        {
            for (int j = i; j < m.size(); j += 1)
            {
                if (m.get(i).messageText.compareTo(m.get(j).messageText) > 0)
                {
                    swap(m, i, j);
                }
            }
        }
    }

    private static void swap(ArrayList<Message> list, int to, int from)
    {
        Message temp = list.get(to);
        list.set(to, list.get(from));
        list.set(from, temp);
    }

}
