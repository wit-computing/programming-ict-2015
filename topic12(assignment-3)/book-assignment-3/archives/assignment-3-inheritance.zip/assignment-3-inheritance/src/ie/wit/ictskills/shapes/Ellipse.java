package ie.wit.ictskills.shapes;

import ie.wit.ictskills.util.ellipse.EllipseMeasure;

import java.awt.geom.*;

/**
 * An ellipse that can be manipulated and that draws itself on a canvas.
 * 
 * @author  Michael Kolling and David J. Barnes
 * @author  jfitzgerald 2014.04.02
 * @version 2006.03.30
 */

public class Ellipse extends Shapes implements Measurable

{
    protected int xdiameter;
    private int ydiameter;
    
    /**
     * Create a new Ellipse at default position with default color.
     */
    public Ellipse()
    {
        super(20, 60, "blue", true);
        setState(70, 40);
    }
    
    public Ellipse (int xdiameter, int ydiameter, int xPosition, int yPosition, String color)
    {
        super(xPosition, yPosition, color, true);
        setState(xdiameter, ydiameter);
    }
    
    public void setState(int xdiameter, int ydiameter)
    {
        this.xdiameter = xdiameter;
        this.ydiameter = ydiameter;
    }
    
    void changeSize(int scale)
    {
        super.erase();
        this.xdiameter *= scale;
        this.ydiameter *= scale;
        draw();
    }
    
    /**
     * Draw the circle with current specifications on screen.
     */
    void draw()
    {
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, color, new Ellipse2D.Double(xPosition, yPosition, 
                                                          xdiameter, ydiameter));
            canvas.wait(10);
        }
    }

	@Override
	public double perimeter() 
	{   
		return EllipseMeasure.perimeter(xdiameter, ydiameter);
	}

}
