package ie.wit.ictskills.shapes;

// TODO: Fully implement this interface in classes Circle, Pentagon, Rectangle, Triangle, Ellipse
public interface Measurable 
{
	double perimeter();
}