package util;

import ie.wit.ictskills.shapes.Measurable;

import java.util.ArrayList;

public class Util 
{
	/**
	 * Calculates the single value representing the largest
	 * perimeter discovered in the list of Measurable objects.
	 *
	 * @param object The list of objects whose classes implement the interface Measurable
	 * @return Returns the largest perimeter discovered among entire list objects.
	 */
	static public double maximum(ArrayList<Measurable> object) 
	{
		double max = 0;
		// TODO: Implement this method Util.maximum
		return max;
	}
}
