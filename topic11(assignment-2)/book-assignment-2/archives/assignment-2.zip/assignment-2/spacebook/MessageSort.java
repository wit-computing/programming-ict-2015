import java.util.ArrayList;

public class MessageSort
{
    //Task 9
    public static void selectionSort(Message[] m)
    {
        //TODO... 
    }

    private static void swap(Message[] arMsg, int to, int from)
    {
        //TODO...
    }
    
    //Task 10
    public static void selectionSort(ArrayList<Message> m)
    {
        //TODO...
    }

    private static void swap(ArrayList<Message> list, int to, int from)
    {
        //TODO...
    }

}
