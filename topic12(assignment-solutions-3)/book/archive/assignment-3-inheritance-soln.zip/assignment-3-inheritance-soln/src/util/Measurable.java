package util;

public interface Measurable 
{
	double perimeter();
}