package util;

import java.util.ArrayList;

import shapes.Measurable;

public class Util 
{
	static public double maximum(ArrayList<Measurable> object) 
	{
		double max = object.get(0).perimeter();
		for (int i = 1; i < object.size(); i += 1) 
		{
			double val = object.get(i).perimeter();
			max = val > max ? val : max;
		}
		return max;
	}
}
