package shapes;
/**
 * @file    Rectangle.java
 * @brief   This class describes a rectangle and includes 
 *                  methods to change rectangle objects' size and appearance.
 *                  
 * @author   jfitzgerald 2014-05-23
 * 
 */

public class Rectangle extends Shapes implements Measurable
{
    private int xSideLength;
    private int ySideLength;

    /**
     * Constructs a new Rectangle defined by default data
     */
    public Rectangle()
    {
        //super(xPosition, yPosition, color, isVisible)
        super(60, 50, "red", true);
        //setState(xSideLength, ySideLength)
        setState(60, 30);
    }
    /**
     * Instantiates Rectangle, a subclass of Shapes
     * @param xSideLength the length of the rectangle
     * @param ySideLength the width or height of the rectangle
     * @param xPosition the x-coordinate of the top left corner of the rectangle
     * @param yPosition the y-coordinate of the top left corner of the rectangle
     * @param color the colour of the rectangle including perimeter and body
     */
    public Rectangle(int xSideLength, int ySideLength, int xPosition, int yPosition, String color)
    {
        super(xPosition, yPosition, color, true);
        setState(xSideLength, ySideLength);
    }
    
    private void setState(int xSideLength, int ySideLength)
    {
        this.xSideLength = xSideLength;
        this.ySideLength = ySideLength;
    }
    
    public void changeSize(int scale)
    {

            erase();
            this.xSideLength *= scale;
            this.ySideLength *= scale;
            draw();
    }

    
    void draw()
    {
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, color,
                new java.awt.Rectangle(xPosition, yPosition, xSideLength, ySideLength));
            canvas.wait(10);
        }
    }
	@Override
	public double perimeter() 
	{ 
		return 2*(xSideLength + ySideLength);
	}


}