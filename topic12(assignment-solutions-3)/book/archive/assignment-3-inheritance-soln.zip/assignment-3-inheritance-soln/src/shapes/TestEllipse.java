package shapes;

public class TestEllipse
{

  public static void main(String[] args) throws InterruptedException
  {
    Ellipse ellipse = new Ellipse(100, 50, 50, 100, "blue");
    ellipse.draw();
    Thread.sleep(1000);
    ellipse.changeSize(2);
    Thread.sleep(1000);
    ellipse.moveTo(80, 25);
    Thread.sleep(1000);
    ellipse.changeColor("red");
  }

}
