package shapes;

public class TestRectangle
{
  public static void main(String[] args) throws InterruptedException
  {
    Rectangle rectangle = new Rectangle(100, 50, 0, 0, "red");
    rectangle.draw();
    Thread.sleep(1000);
    rectangle.moveTo(50,  100);
  }

}
