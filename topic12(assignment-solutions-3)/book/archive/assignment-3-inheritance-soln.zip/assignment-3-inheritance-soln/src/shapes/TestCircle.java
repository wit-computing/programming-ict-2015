package shapes;

public class TestCircle
{
    public static void main(String[] args)
    {
        //Create an array of Shapes
        int nmrShapes = 4;
        Shapes[] shapes = new Shapes[nmrShapes];
        
        //Initialize array Shapes with default Circle objects and display
        for(int i = 0; i < shapes.length; i += 1)
        {
            shapes[i] = new Circle(10+i, 0, 0, "red");
            shapes[i].makeVisible();
        }
        String[] colors = {"red", "blue", "black", "yellow"};
        
        for(int i = 0; i < shapes.length; i += 1)
        {
          shapes[i].changeSize(2+i);
          shapes[i].moveTo(100 + 10*i, 100 + 10*i);
          shapes[i].changeColor(colors[i]);
        }
            
        
    }
}