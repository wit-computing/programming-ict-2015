package shapes;

public interface Measurable 
{
	double perimeter();
}
