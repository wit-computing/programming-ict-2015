/**
 * @file    Book.java
 * @brief   This class defines the basic description of a book and provides some characteristic methods.
 * @version 1.0 February 5 2015
 * @author  john doe
 */
public class Book
{

    String      title;
    String      author;
    String      isbn;
    int         numberPages;
    boolean     borrowed;
    int         numberBorrowings;

    /**
     * Sole constructor 
     * @param title   the complete book title
     * @param author  the author or authors
     * @param isbn    the International Standard Book Number 2005 edition (ISBN-13)
     */
    public Book(String title, String author, String isbn)
    {
        this.title   = title;
        this.author  = author;
        this.isbn    = isbn;
    }

    /**
     * Sets number pages in book
     * @param numberPages   the number of pages in book
     */
    public void setPages(int numberPages)
    {
        this.numberPages = numberPages;
    }

    /**
     * Simulates borrowing of book
     * Checks if book already borrowed (on loan).
     * If not already on loan, increments the number of borrowings and changes state to reflect book now being borrowed.
     */
    public void borrow()
    {
        if(!borrowed)
        {
            numberBorrowings += 1;
            borrowed = true;
        }
        else
        {
            System.out.println("Book on loan");
        }
    }

    /**
     * Informs whether or not book is borrowed, that is, presently out on loan
     * 
     * @return true if the book is presently borrowed else returns false
     */
    public boolean isBorrowed()
    {
        return borrowed;
    }

    /**
     * Method that simulates returning of borrowed book to the library.
     * Alters the book object state to reflect the changed status.
     */
    public void returns()
    {
        borrowed = false;
    }

    /**
     * Prints summary data relating to book
     */
    public void printDetails()
    {
        System.out.println("Title      :  " + title);
        System.out.println("Author     :  " + author); 
        System.out.println("Pages      :  " + numberPages);
        System.out.println("ISBN       :  " + isbn);
        System.out.println("Borrowed   :  " + numberBorrowings + " times");
        System.out.println(loanStatus());
    }

    private String loanStatus()
    {
        if(borrowed)
            return "Unavailable: presently on loan";
        else
            return "Book is available";
    }

    public static void main(String[] args)
    {
        Book b = new Book("Objects First with Java", "Barnes & Kolling", "978-0-13-249266-9");
        b.borrowed = true;
        b.numberBorrowings = 12;
        b.numberPages = 545;
        b.printDetails();

    }

}
