/**
 * @file    Circle.java
 * @brief   This class defines the basic description of a book and provides some characteristic methods.
 * @version 1.0 February 5 2015
 * @author  john doe
 */
public class Circle
{
    double radius;
    double xCentre;
    double yCentre;

    /**
     * Constructs circle object with user-provided radius dimension.
     * 
     * @param radius the radius of the circle
     */
    public Circle(double radius)
    {
        setState(radius, 0, 0);
    }

    /**
     * Constructs circle object with user-provided radius dimension.
     * The coordinates of the centre are also provided by the user.
     * 
     * @param radius  the radius of the circle
     * @param xCentre the x-coordinate of the circle object's centre
     * @param yCentre the y-coordinate of the circle object's centre
     */
    public Circle (double radius, double xCentre, double yCentre)
    {
        setState(radius, xCentre, yCentre);
    }

    /**
     * Helper method to set state of circle object
     * 
     * @param radius  the radius of the circle
     * @param xCentre the x-coordinate of the circle object's centre
     * @param yCentre the y-coordinate of the circle object's centre
     */
    public void setState(double radius, double xCentre, double yCentre)
    {
        if(isValid(radius) && isValid(xCentre) && isValid(yCentre))
        {
            this.radius  = radius;
            this.xCentre = xCentre;
            this.yCentre = yCentre;
        }
        else
        {
            System.out.println("Input valid data: negative input values disallowed");
            setState(0, 0, 0);
        }
    }

    /**
     * Calculate and returns area of circle object
     * 
     * @return the area of the circle  
     */
    public double area()
    {
        return Math.PI*Math.pow(radius, 2);
    }

    /**
     * Calculates and returns the circumference of circle object
     * 
     * @return  the circumference of circle object
     */
    public double circumference()
    {
        return Math.PI*radius*2;
    }

    /**
     * Resets the coordinates of the centre of the circle object
     * 
     * @param xCentre replacement x-coordinate of the circle object's centre
     * @param yCentre replacement y-coordinate of the circle object's centre
     */
    public void move(double xCentre, double yCentre)
    {
        if(isValid(xCentre) && isValid(yCentre))
        {
            this.xCentre = xCentre;
            this.yCentre = yCentre;
        }
    }

    /**
     * Calculates and returns the area of a sector of circle object
     * The extent of sector defined by angle (in radians).
     * Whereas angle input may be in range minus infinity to plus infinity (any valid double value)
     * range used is in range [0, 2*pi).
     * 
     * @param angle in radians : range any valid double primitive value (positive or negative)
     * @return the area of the sector
     */
    public double areaSector(double angle)
    {
        angle = Math.abs(angle % (2*Math.PI));
        return Math.pow(radius, 2)*angle*0.5;
    }

    /*
     * Helper method to verify if parameter value is greater than or equal to zero.
     * Returns false if value less than zero else returns true.
     */
    private boolean isValid(double value)
    {
        if(value < 0)
        {
            System.out.println("Please review input: only positive numbers acceptable");
            return false;
        }
        return true;
    }   
}
