
/**
 * Write a description of class ICTSkillsClock1 here.
 * 
 * @author jfitzgerald
 * @version 2015.02.04
 */
public class ICTSkillsClock extends Clock
{
    
    public void resetSeconds(int value)
    {
        clock.resetSeconds(value);
    }
     
    public void resetMinutes(int value)
    {
        clock.resetMinutes(value);
    }
     
    public void resetHours(int value)
    {
        clock.resetHours(value);
    }

}
