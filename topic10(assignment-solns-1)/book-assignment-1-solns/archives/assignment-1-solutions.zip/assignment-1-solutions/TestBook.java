
/**
 * Write a description of class TestBook here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TestBook
{
    Book book;
   
    public void testBook()
    {
        book = new Book("Objects First with Java", "Barnes & Kolling", "978-0-13-249266-9");
        book.borrowed         = true;
        book.numberBorrowings = 12;
        book.numberPages      = 545;
        book.printDetails();
    }
}
