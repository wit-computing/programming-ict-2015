public class ClockDisplay
{

    private NumberDisplay hours;
    private NumberDisplay minutes;
  
    
    private String displayTime;
    
    public ClockDisplay()
    {
      hours     = new NumberDisplay(24);
      minutes   = new NumberDisplay(60);
      
    }
    
    public void updateDisplay()
    {
    
        this.displayTime = hours.display() + ":" + minutes.display();
    }

    public void resetSeconds(int value)
    {
         
    }    
    
    
    public void resetMinutes(int value)
    {
         
    }
    
    public void resetHours(int value)
    {
         
    }
    
    public void timeTick()
    {
 
    }
    
    public String getTime()
    {
        return displayTime;
    }
}