
/**
 * This class is derived from Clock.
 * An instance variable of type ClockDisplay (named clock) is present in Clock.
 * This instance variable clock is 'visible' and available for use in this class.
 * Therefore you may invoke any methods present in ClockDisplay from within methods in this class.
 * For example: clock.updateDisplay() would be a valid statement within any of the methods below.
 * 
 * @author jfitzgerald
 * @version 2015.02.04
 */
public class ICTSkillsClock extends Clock
{
    
    public void resetSeconds(int value)
    {
         
    }
     
    public void resetMinutes(int value)
    {
         
    }
     
    public void resetHours(int value)
    {
         
    }

}
